interface Action {
    void go();
}