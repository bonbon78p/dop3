class Men extends Human {
    public Men(String name, int age) {
        super(name, age);
    }
}