public class Movie {
    private String title;
    private String director;
    private String genre;

    // Конструктор
    public Movie(String title, String director, String genre) {
        this.title = title;
        this.director = director;
        this.genre = genre;
    }

    // Геттеры
    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Название: " + title + ", Режиссёр: " + director + ", Жанр: " + genre;
    }
}