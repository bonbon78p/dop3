import java.util.*;

public class MovieLibrary {
    private List<Movie> movies = new ArrayList<>();
    private Set<String> directors = new HashSet<>();
    private HashMap<String, List<Movie>> moviesByGenre = new HashMap<>();

    // Добавить фильм
    public void addMovie(Movie movie) {
        movies.add(movie);
        directors.add(movie.getDirector());
        moviesByGenre.putIfAbsent(movie.getGenre(), new ArrayList<>());
        moviesByGenre.get(movie.getGenre()).add(movie);
    }

    // Отобразить все фильмы
    public void displayMovies() {
        System.out.println("Список всех фильмов:");
        for (Movie movie : movies) {
            System.out.println(movie);
        }
    }

    // Отобразить всех режиссёров
    public void displayDirectors() {
        System.out.println("Список всех режиссёров:");
        for (String director : directors) {
            System.out.println(director);
        }
    }

    // Отобразить фильмы по жанру
    public void displayMoviesByGenre(String genre) {
        System.out.println("Фильмы в жанре \"" + genre + "\":");
        List<Movie> genreMovies = moviesByGenre.get(genre);
        if (genreMovies != null && !genreMovies.isEmpty()) {
            for (Movie movie : genreMovies) {
                System.out.println(movie);
            }
        } else {
            System.out.println("Нет фильмов в данном жанре.");
        }
    }
}