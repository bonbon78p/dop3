import java.util.Scanner;

public class MovieLibraryApp {
    public static void main(String[] args) {
        MovieLibrary movieLibrary = new MovieLibrary();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nМеню:");
            System.out.println("1. Добавить фильм");
            System.out.println("2. Показать все фильмы");
            System.out.println("3. Показать всех режиссёров");
            System.out.println("4. Показать фильмы по жанру");
            System.out.println("5. Выход");
            System.out.print("Выберите действие: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Считываем остаток строки

            switch (choice) {
                case 1:
                    System.out.print("Введите название фильма: ");
                    String title = scanner.nextLine();

                    System.out.print("Введите режиссёра фильма: ");
                    String director = scanner.nextLine();

                    System.out.print("Введите жанр фильма: ");
                    String genre = scanner.nextLine();

                    Movie movie = new Movie(title, director, genre);
                    movieLibrary.addMovie(movie);
                    System.out.println("Фильм добавлен!");
                    break;

                case 2:
                    movieLibrary.displayMovies();
                    break;

                case 3:
                    movieLibrary.displayDirectors();
                    break;

                case 4:
                    System.out.print("Введите жанр: ");
                    String searchGenre = scanner.nextLine();
                    movieLibrary.displayMoviesByGenre(searchGenre);
                    break;

                case 5:
                    System.out.println("Выход из программы.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Некорректный ввод. Попробуйте снова.");
            }
        }
    }
}
